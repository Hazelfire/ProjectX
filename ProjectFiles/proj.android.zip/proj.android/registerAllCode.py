import os
makeFile = open('jni/Android.mk', 'w')
makeFile.write("""LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

$(call import-add-path,$(LOCAL_PATH)/../../cocos2d)
$(call import-add-path,$(LOCAL_PATH)/../../cocos2d/external)
$(call import-add-path,$(LOCAL_PATH)/../../cocos2d/cocos)

LOCAL_MODULE := cocos2dcpp_shared

LOCAL_MODULE_FILENAME := libcocos2dcpp

LOCAL_SRC_FILES := hellocpp/main.cpp""")

ommitedDirs = ["../Classes/boost","../Classes/Multiplayer/websocketsAPI","../Classes/YAML/API/test","../Classes/YAML/API/util"  ]

for root, dir, files in os.walk("../Classes"):
    
    for file in files:
        foundDirectory = False
        for omitDir in ommitedDirs:
            if os.path.join(root, file).replace("\\", "/").find(omitDir) == 0:
                foundDirectory = True

        if foundDirectory:
            continue
    
        if file.endswith(".cpp") or file.endswith(".c"):
            makeFile.write(" \\\n" + (" ../" + os.path.join(root, file)).replace("\\", "/"))
            #print ((("\\\n ../" + os.path.join(root, file)).replace("\\", "/")))
makeFile.write("""

LOCAL_C_INCLUDES := $(LOCAL_PATH)/../../Classes
LOCAL_C_INCLUDES += $(LOCAL_PATH)/../../Classes/YAML/API/include
LOCAL_C_INCLUDES += $(LOCAL_PATH)/../../Classes/Lua/API

# _COCOS_HEADER_ANDROID_BEGIN
# _COCOS_HEADER_ANDROID_END

LOCAL_STATIC_LIBRARIES := cocos2dx_static

# _COCOS_LIB_ANDROID_BEGIN
# _COCOS_LIB_ANDROID_END

include $(BUILD_SHARED_LIBRARY)

$(call import-module,.)

# _COCOS_LIB_IMPORT_ANDROID_BEGIN
# _COCOS_LIB_IMPORT_ANDROID_END

LOCAL_ALLOW_UNDEFINED_SYMBOLS := true""")
makeFile.close();
